<?php
namespace app\admin\model\myadmin;
use think\Model;
class Net_segment extends Model
{


}
?>