<?php
namespace app\admin\model\myadmin;
use think\Model;
class Log_operations extends Model
{


}
?>