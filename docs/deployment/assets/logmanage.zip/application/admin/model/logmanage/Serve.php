<?php
namespace app\admin\model\logmanage;
use think\Model;
class Serve extends Model
{


}
?>