<?php
namespace app\admin\model\logmanage;
use think\Model;
class Log_operations extends Model
{


}
?>