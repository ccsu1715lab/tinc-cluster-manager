<?php
namespace app\admin\model\logmanage;
use think\Model;
class Node extends Model
{


}
?>