<?php
namespace app\admin\model\logmanage;
use think\Model;
class Net extends Model
{


}
?>