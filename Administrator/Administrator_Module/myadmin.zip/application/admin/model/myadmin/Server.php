<?php
namespace app\admin\model\myadmin;
use think\Model;
class Server extends Model
{


}
?>