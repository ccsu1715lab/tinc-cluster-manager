<?php

return array(
    array(
        'name'    => '__tips__',
        'title'   => '温馨提示',
        'type'    => '',
        'content' =>
            array(),
        'value'   => '请做好数据库离线备份工作，建议此插件仅用于开发阶段，项目正式上线建议卸载此插件',
        'rule'    => '',
        'msg'     => '',
        'tip'     => '',
        'ok'      => '',
        'extend'  => '',
    ),
);
