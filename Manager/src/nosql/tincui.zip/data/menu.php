<?php

$menu = [
        [
            'name'   => 'tincui/singlenwdata',
            'title'  => '单网数据可视化',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],
        [
            'name'   => 'tincui/nwdata',
            'title'  => '网络集群数据可视化',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],
        [
            'name'   => 'tincui/netmanagement',
            'title'  => 'Tinc服务端',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],
        [
            'name'   => 'tincui/nodemanagement',
            'title'  => 'Tinc客户端',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],  
        [
           'name'   => 'tincui/events',
           'title'  => '事件查询',
           'icon'   => 'fa fa-gears',
           'ismenu' => 1,
       ],

   
];
return $menu;
