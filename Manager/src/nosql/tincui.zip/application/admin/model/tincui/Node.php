<?php
namespace app\admin\model\tincui;
use think\Model;
class Node extends Model
{
    
}
?>