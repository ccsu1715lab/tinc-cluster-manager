<?php
namespace app\admin\model\tincui;
use think\Model;
class Event extends Model
{
    
}
?>