<?php

$menu = [
        [
            'name'   => 'tincui/Singlenwdata',
            'title'  => '单网数据可视化',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],
        [
            'name'   => 'tincui/Nwdata',
            'title'  => '网络集群数据可视化',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],
        [
            'name'   => 'tincui/netmanagement',
            'title'  => 'Tinc服务端',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],
        [
            'name'   => 'tincui/nodemanagement',
            'title'  => 'Tinc客户端',
            'icon'   => 'fa fa-gears',
            'ismenu' => 1,
        ],  
        [
           'name'   => 'tincui/events',
           'title'  => '事件查询',
           'icon'   => 'fa fa-gears',
           'ismenu' => 1,
       ],

   
];
return $menu;
