##Tincs类
import ipaddress
import os
import platform
import subprocess   
from modle import get_tincd_pid_by_network
class Tincs:
    TINC_PATH='/etc/tinc'
    network_name=''
    pub_ip=''
    pri_ip=''
    port=-1
    network_address=''
    netmask=''
    status=''
    create_time=''
    Conf_content=''
    Tincup_content=''
    Tincdown_content=''
    Main_content=''
    
    def __init__(self,network_name,pub_ip,pri_ip,port,create_time):
        self.network_name=network_name
        self.pub_ip=pub_ip
        self.pri_ip=pri_ip
        self.network_address=self.ip_to_network(pri_ip)['network_address']
        self.netmask=self.ip_to_network(pri_ip)['netmask']
        self.port=port
        self.create_time=create_time
        self.Conf_content=f"Name = main
                            Device = /dev/net/tun
                            Port = {self.port}"
        self.Tincup_content=f"ip link set $INTERFACE up
                              ip addr add {self.pri_ip}/32 dev $INTERFACE
                              ip route add {self.network_address}/24 dev $INTERFACE"
        self.Tincdown_content=f"ip route del {self.network_address}/24 dev $INTERFACE
                                ip addr del {self.pri_ip}/32 dev $INTERFACE
                                ip link set $INTERFACE down"
        self.Main_content=f"Address = {self.pub_ip}
                            Subnet = 0.0.0.0/0
                            Port = {self.port}"
        
    def ip_to_network(ip_address):
        try:
            # 创建IPv4网络对象，使用24位掩码
            network = ipaddress.IPv4Network(f"{ip_address}/24", strict=False)
            # 获取网络地址
            network_address = network.network_address
            # 获取网络掩码
            netmask = network.netmask
            return {
                'network_address': str(network_address),
                'netmask': str(netmask),
                'network': str(network)
            }
        except ValueError as e:
            print(f"错误: {e}")
            return None

    def get_networkname(self):
        return self.network_name
    
    def get_pub_ip(self):
        return self.pub_ip
    
    def get_pri_ip(self):
        return self.pri_ip
    
    def get_port(self):
        return self.port    
    
    def get_net_id(self):
        return self.net_id
    
    def get_status(self):
        return self.status  
    
    def get_create_time(self):
        return self.create_time
    
    ##创建内网文件目录
    def create_net_dir(self):
        print(f"正在创建内网文件目录:{self.network_name}")
        os.makedirs(self.TINC_PATH+'/'+self.network_name)
        os.makedirs(self.TINC_PATH+'/'+self.network_name+'/hosts')
        with open(self.TINC_PATH+'/'+self.network_name+'/'+"tinc.conf",'w') as f:
            f.write(self.Conf_content)  
        with open(self.TINC_PATH+'/'+self.network_name+'/'+"tinc-down",'w') as f:
            f.write(self.Tincdown_content)
        with open(self.TINC_PATH+'/'+self.network_name+'/'+"tinc-up",'w') as f:
            f.write(self.Tincup_content)
        with open(self.TINC_PATH+'/'+self.network_name+'/'+'hosts/'+"main",'w') as f:
            f.write(self.Main_content)
        
        
    ##删除内网文件目录
    def delete_net_dir(self):
        if os.path.exists(self.TINC_PATH+'/'+self.network_name):
            print(f"正在删除内网文件目录:{self.network_name}")
            os.rmdir(self.TINC_PATH+'/'+self.network_name)
        else:
            print(f"内网文件目录:{self.network_name}不存在")
        
    ##设置开机自启服务
    def set_auto_start(self):
        print(f"正在设置开机自启服务:{self.network_name}")
        
    ##删除开机自启服务
    def delete_auto_start(self):
        print(f"正在删除开机自启服务:{self.network_name}")
        
    def ping_host(self,host, count=4, timeout=1):
        # 根据操作系统选择ping命令
        param = '-n' if platform.system().lower() == 'windows' else '-c'
        # 构建ping命令
        command = ['ping', param, str(count), '-w', str(timeout), host]
        try:
            # 执行ping命令
            output = subprocess.run(command, 
                                stdout=subprocess.PIPE, 
                                stderr=subprocess.PIPE,
                                text=True)
            # 检查返回码和输出
            if output.returncode == 0:
                print(f"主机 {host} 可达")
                print("Ping结果:")
                print(output.stdout)
                print("Tincs服务配置成功")
                return True
            else:
                print(f"主机 {host} 不可达")
                print("错误信息:")
                print(output.stderr)
                print("Tincs服务配置失败")
                return False
        except Exception as e:
            print(f"执行ping命令时出错: {str(e)}")
            return False
        finally:
            ##杀死tincs进程
            pid=get_tincd_pid_by_network(self.network_name)['pid']
            os.system(f"kill -9 {pid}")
            print(f"杀死tincs进程:{pid}")
    ##配置Tincs服务
    def config_tincs_service(self):
        print(f"正在配置Tincs服务:{self.network_name}")
        os.system(f"tincd -n {self.network_name} -K")
        os.system(f"tincd -n {self.network_name} -d5 -D")
        self.ping_host(self.pri_ip)
        
        
    ##停止Tincs服务
    def stop_tincs_service(self):
        print(f"正在停止Tincs服务:{self.network_name}")
        os.system(f"tincd -n {self.network_name} -d")
    ##创建Tincs服务
    def create_tincs_service(self):
        print(f"正在创建Tincs服务:{self.network_name}")
        self.create_net_dir()
        self.start_tincs_service()
        self.set_auto_start()
        
    def delete_tincs_service(self):
        print(f"正在删除Tincs服务:{self.network_name}")
        ##杀死tincs进程
        ##删除目录
        self.delete_net_dir()
        ##删除开机自启服务
        self.delete_auto_start()
        
    def display_tincs_info(self):
        print(f"Tincs服务配置文件:{self.network_name}")
        print(f"公网IP:{self.pub_ip}")
        print(f"私网IP:{self.pri_ip}")
        print(f"端口号:{self.port}")
        print(f"内网ID:{self.net_id}")
        print(f"创建时间:{self.create_time}")
        print("--------------------------------")
        
        
        
  
        
    
